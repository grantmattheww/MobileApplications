package id.ac.umn.projectuts_00000012953_bookdatabase;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {
    List<Book> listBook = new ArrayList<>();
    DBAdapter dbHelper;
    LinearLayout container;
    private SharedPreferenceConfig preferenceConfig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        container = findViewById(R.id.content);
        dbHelper = new DBAdapter(getApplicationContext());
        dbHelper.createDatabase();

        listBook = dbHelper.getAllBooks();
        showData();
    }

    public void showData(){
        if(container.getChildCount() > 0) container.removeAllViews();
        for (final Book book : listBook) {
            LayoutInflater inflater = (LayoutInflater) getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View addView = inflater.inflate(R.layout.activity_second2, null);
            TextView dataTitle = addView.findViewById(R.id.id_title);
            TextView dataAuthor = addView.findViewById(R.id.id_author);

            dataTitle.setText(book.get_title());
            dataAuthor.setText(book.get_author());

            final Book obj = book;
            ImageButton btnFavorite = addView.findViewById(R.id.favorite);
            final ImageButton imgButton = btnFavorite;
            final ContentValues cv = new ContentValues();
            imgButton.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    if(obj.get_favorite() == 0){
                        imgButton.setImageResource(R.drawable.ic_star_black_24dp);
                        cv.put("FAVORITE", 1);
                        obj.set_favorite(1);
                        Log.e("debug", "test A");
                        Toast.makeText(SearchActivity.this, "Yay! Item telah ditambahkan ke Favorite", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        imgButton.setImageResource(R.drawable.ic_star_border_black_24dp);
                        cv.put("FAVORITE", 0);
                        obj.set_favorite(0);
                        Log.e("debug", "test A");
                        Toast.makeText(SearchActivity.this, "Yay! Item telah dihapus dari Favorite", Toast.LENGTH_SHORT).show();
                    }

                    dbHelper.updateDatabase(cv, obj.get_asin());
                }
            });

            if(obj.get_favorite() == 0){
                imgButton.setImageResource(R.drawable.ic_star_border_black_24dp);
            }
            else{
                imgButton.setImageResource(R.drawable.ic_star_black_24dp);
            }
            final View card_view = addView;
            card_view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final Intent details = new Intent(SearchActivity.this, BookDetailsActivity.class);

                    Bundle bun = new Bundle();

                    bun.putString("title", book.get_title());
                    bun.putString("author", book.get_author());
                    bun.putString("asin", book.get_asin());
                    bun.putString("group", book.get_group());
                    bun.putString("format", book.get_format());
                    bun.putString("publisher", book.get_publisher());

                    details.putExtras(bun);
                    startActivity(details);

                }
            });

            container.addView(addView);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);

        return true;
    }

    final String TAG = MainActivity.class.getSimpleName();
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_dialog_sortBy:
                AlertDialog.Builder builder = new AlertDialog.Builder(SearchActivity.this);

                builder
                        .setTitle("Sort By")
                        .setMessage("Anda Mau Mengurutkan Buku Berdasarkan Apa?")
                        .setPositiveButton("Title", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                listBook = dbHelper.getAllBooksSortTitle();
                                showData();

                            }
                        })
                        .setNegativeButton("Author", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                listBook = dbHelper.getAllBooksSortAuthor();
                                showData();
                            }
                        });

                AlertDialog dialog = builder.create();
                dialog.show();

                return true;

            case R.id.menu_dialog_aboutMe:
                Intent aboutMe = new Intent(SearchActivity.this, AboutMeActivity.class);
                startActivity(aboutMe);

                return true;

            case R.id.menu_dialog_myFavorite:
                Intent favorite = new Intent(SearchActivity.this, SecondActivity.class);
                startActivity(favorite);
                listBook = dbHelper.getAllBooksFavorite();

                showData();

                return true;

            case R.id.menu_dialog_logout:
                preferenceConfig.writeLoginStatus(false);
                startActivity(new Intent(this, MainActivity.class));
                finish();

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
