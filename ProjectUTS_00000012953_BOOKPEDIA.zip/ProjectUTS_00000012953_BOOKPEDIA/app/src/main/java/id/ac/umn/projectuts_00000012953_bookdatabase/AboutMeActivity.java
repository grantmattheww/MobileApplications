package id.ac.umn.projectuts_00000012953_bookdatabase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AboutMeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_me);
    }
}
